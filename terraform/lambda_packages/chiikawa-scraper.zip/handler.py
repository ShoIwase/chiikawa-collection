def lambda_handler(e, c): return {"statusCode": 200}
